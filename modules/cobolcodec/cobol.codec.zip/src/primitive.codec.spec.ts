import {
    asciiCodec,
    binaryIntegerCodec,
    ieee754Codec,
    packedDecimalCodec,
} from "./primitive.codec";

import {
    DecimalFieldType,
    FloatingPointFieldType,
    IntegerFieldType,
} from "@cobol-ts/copybookfiles";


const fieldName =
    "TEST-FIELD";


describe("asciiCodec", () => {

    test("reads ASCII", () => {
        const bytes =
            new Uint8Array([
                0x41,
                0x42,
                0x43,
            ]);

        expect(
            asciiCodec.read(
                bytes,
                0,
                3,
            ),
        ).toBe("ABC");
    });


    test("writes ASCII", () => {
        const bytes =
            new Uint8Array(3);

        asciiCodec.write(
            bytes,
            0,
            3,
            "ABC",
        );

        expect(
            Array.from(bytes),
        ).toEqual([
            0x41,
            0x42,
            0x43,
        ]);
    });


    test("pads with spaces", () => {
        const bytes =
            new Uint8Array(5);

        asciiCodec.write(
            bytes,
            0,
            5,
            "ABC",
        );

        expect(
            Array.from(bytes),
        ).toEqual([
            0x41,
            0x42,
            0x43,
            0x20,
            0x20,
        ]);
    });


    test("rejects value that does not fit", () => {
        expect(
            asciiCodec.validateValue(
                fieldName,
                3,
                "ABCD",
            ),
        ).toBe(
            "TEST-FIELD: value requires 4 bytes but field has 3",
        );
    });


    test("rejects non ASCII character", () => {
        expect(
            asciiCodec.validateValue(
                fieldName,
                10,
                "ABC£",
            ),
        ).toBe(
            'TEST-FIELD: character "£" cannot be encoded as ASCII',
        );
    });


    test("accepts valid value", () => {
        expect(
            asciiCodec.validateValue(
                fieldName,
                3,
                "ABC",
            ),
        ).toBeUndefined();
    });


    test("round trips", () => {
        const bytes =
            new Uint8Array(5);

        asciiCodec.write(
            bytes,
            0,
            5,
            "Hello",
        );

        expect(
            asciiCodec.read(
                bytes,
                0,
                5,
            ),
        ).toBe("Hello");
    });

});


describe("binaryIntegerCodec", () => {

    const unsignedBigEndian:
        IntegerFieldType = {
        kind: "integer",
        signed: false,
        encoding: {
            kind: "binary",
            byteOrder: "big-endian",
            semantics: "native",
        },
    };


    const signedBigEndian:
        IntegerFieldType = {
        kind: "integer",
        signed: true,
        encoding: {
            kind: "binary",
            byteOrder: "big-endian",
            semantics: "native",
        },
    };


    const unsignedLittleEndian:
        IntegerFieldType = {
        kind: "integer",
        signed: false,
        encoding: {
            kind: "binary",
            byteOrder: "little-endian",
            semantics: "native",
        },
    };


    test("reads unsigned big endian", () => {
        const codec =
            binaryIntegerCodec(
                unsignedBigEndian,
            );

        const bytes =
            new Uint8Array([
                0x01,
                0x02,
            ]);

        expect(
            codec.read(
                bytes,
                0,
                2,
            ),
        ).toBe(0x0102n);
    });


    test("reads unsigned little endian", () => {
        const codec =
            binaryIntegerCodec(
                unsignedLittleEndian,
            );

        const bytes =
            new Uint8Array([
                0x02,
                0x01,
            ]);

        expect(
            codec.read(
                bytes,
                0,
                2,
            ),
        ).toBe(0x0102n);
    });


    test("reads signed negative value", () => {
        const codec =
            binaryIntegerCodec(
                signedBigEndian,
            );

        expect(
            codec.read(
                new Uint8Array([
                    0xff,
                ]),
                0,
                1,
            ),
        ).toBe(-1n);

        expect(
            codec.read(
                new Uint8Array([
                    0x80,
                ]),
                0,
                1,
            ),
        ).toBe(-128n);
    });


    test("writes big endian", () => {
        const codec =
            binaryIntegerCodec(
                unsignedBigEndian,
            );

        const bytes =
            new Uint8Array(2);

        codec.write(
            bytes,
            0,
            2,
            0x0102n,
        );

        expect(
            Array.from(bytes),
        ).toEqual([
            0x01,
            0x02,
        ]);
    });


    test("writes little endian", () => {
        const codec =
            binaryIntegerCodec(
                unsignedLittleEndian,
            );

        const bytes =
            new Uint8Array(2);

        codec.write(
            bytes,
            0,
            2,
            0x0102n,
        );

        expect(
            Array.from(bytes),
        ).toEqual([
            0x02,
            0x01,
        ]);
    });


    test("writes signed negative value", () => {
        const codec =
            binaryIntegerCodec(
                signedBigEndian,
            );

        const bytes =
            new Uint8Array(2);

        codec.write(
            bytes,
            0,
            2,
            -2n,
        );

        expect(
            Array.from(bytes),
        ).toEqual([
            0xff,
            0xfe,
        ]);
    });


    test("validates unsigned one byte range", () => {
        const codec =
            binaryIntegerCodec(
                unsignedBigEndian,
            );

        expect(
            codec.validateValue(
                fieldName,
                1,
                0n,
            ),
        ).toBeUndefined();

        expect(
            codec.validateValue(
                fieldName,
                1,
                255n,
            ),
        ).toBeUndefined();

        expect(
            codec.validateValue(
                fieldName,
                1,
                256n,
            ),
        ).toBe(
            "TEST-FIELD: value 256 does not fit in unsigned 1-byte integer",
        );

        expect(
            codec.validateValue(
                fieldName,
                1,
                -1n,
            ),
        ).toBe(
            "TEST-FIELD: unsigned integer cannot contain a negative value",
        );
    });


    test("validates signed one byte range", () => {
        const codec =
            binaryIntegerCodec(
                signedBigEndian,
            );

        expect(
            codec.validateValue(
                fieldName,
                1,
                -128n,
            ),
        ).toBeUndefined();

        expect(
            codec.validateValue(
                fieldName,
                1,
                127n,
            ),
        ).toBeUndefined();

        expect(
            codec.validateValue(
                fieldName,
                1,
                -129n,
            ),
        ).toBe(
            "TEST-FIELD: value -129 does not fit in signed 1-byte integer",
        );

        expect(
            codec.validateValue(
                fieldName,
                1,
                128n,
            ),
        ).toBe(
            "TEST-FIELD: value 128 does not fit in signed 1-byte integer",
        );
    });


    test.each([
        0n,
        1n,
        255n,
        256n,
        65535n,
    ])(
        "round trips unsigned value %s",
        value => {
            const codec =
                binaryIntegerCodec(
                    unsignedBigEndian,
                );

            const bytes =
                new Uint8Array(8);

            codec.write(
                bytes,
                0,
                8,
                value,
            );

            expect(
                codec.read(
                    bytes,
                    0,
                    8,
                ),
            ).toBe(value);
        },
    );


    test.each([
        -32768n,
        -1n,
        0n,
        1n,
        32767n,
    ])(
        "round trips signed value %s",
        value => {
            const codec =
                binaryIntegerCodec(
                    signedBigEndian,
                );

            const bytes =
                new Uint8Array(2);

            expect(
                codec.validateValue(
                    fieldName,
                    2,
                    value,
                ),
            ).toBeUndefined();

            codec.write(
                bytes,
                0,
                2,
                value,
            );

            expect(
                codec.read(
                    bytes,
                    0,
                    2,
                ),
            ).toBe(value);
        },
    );

});


describe("ieee754Codec", () => {

    const singleBigEndian:
        FloatingPointFieldType = {
        kind: "floating-point",
        encoding: {
            kind: "ieee754",
            precision: "single",
            byteOrder: "big-endian",
        },
    };


    const doubleLittleEndian:
        FloatingPointFieldType = {
        kind: "floating-point",
        encoding: {
            kind: "ieee754",
            precision: "double",
            byteOrder: "little-endian",
        },
    };


    test("writes known single precision bytes", () => {
        const codec =
            ieee754Codec(
                singleBigEndian,
            );

        const bytes =
            new Uint8Array(4);

        codec.write(
            bytes,
            0,
            4,
            1,
        );

        expect(
            Array.from(bytes),
        ).toEqual([
            0x3f,
            0x80,
            0x00,
            0x00,
        ]);
    });


    test("reads known single precision bytes", () => {
        const codec =
            ieee754Codec(
                singleBigEndian,
            );

        expect(
            codec.read(
                new Uint8Array([
                    0x3f,
                    0x80,
                    0x00,
                    0x00,
                ]),
                0,
                4,
            ),
        ).toBe(1);
    });


    test("round trips double precision", () => {
        const codec =
            ieee754Codec(
                doubleLittleEndian,
            );

        const bytes =
            new Uint8Array(8);

        codec.write(
            bytes,
            0,
            8,
            123.456,
        );

        expect(
            codec.read(
                bytes,
                0,
                8,
            ),
        ).toBe(123.456);
    });


    test("validates single precision size", () => {
        const codec =
            ieee754Codec(
                singleBigEndian,
            );

        expect(
            codec.validateValue(
                fieldName,
                4,
                1,
            ),
        ).toBeUndefined();

        expect(
            codec.validateValue(
                fieldName,
                8,
                1,
            ),
        ).toBe(
            "TEST-FIELD: IEEE-754 single requires 4 bytes but field has 8",
        );
    });


    test("validates byte size", () => {
        const codec =
            ieee754Codec(
                singleBigEndian,
            );

        expect(
            codec.validateBytes(
                fieldName,
                new Uint8Array(8),
                0,
                4,
            ),
        ).toBeUndefined();

        expect(
            codec.validateBytes(
                fieldName,
                new Uint8Array(8),
                0,
                8,
            ),
        ).toBe(
            "TEST-FIELD: IEEE-754 single requires 4 bytes but field has 8",
        );
    });


    test.each([
        0,
        -1,
        1,
        123.5,
        Number.POSITIVE_INFINITY,
        Number.NEGATIVE_INFINITY,
    ])(
        "round trips %s",
        value => {
            const codec =
                ieee754Codec(
                    doubleLittleEndian,
                );

            const bytes =
                new Uint8Array(8);

            codec.write(
                bytes,
                0,
                8,
                value,
            );

            expect(
                codec.read(
                    bytes,
                    0,
                    8,
                ),
            ).toBe(value);
        },
    );


    test("round trips NaN", () => {
        const codec =
            ieee754Codec(
                doubleLittleEndian,
            );

        const bytes =
            new Uint8Array(8);

        codec.write(
            bytes,
            0,
            8,
            Number.NaN,
        );

        expect(
            codec.read(
                bytes,
                0,
                8,
            ),
        ).toBeNaN();
    });

});


describe("packedDecimalCodec", () => {

    const signedDecimal:
        DecimalFieldType = {
        kind: "decimal",
        digits: 5,
        scale: 2,
        signed: true,
        encoding: {
            kind: "packed-decimal",
        },
    };


    const unsignedDecimal:
        DecimalFieldType = {
        kind: "decimal",
        digits: 5,
        scale: 2,
        signed: false,
        encoding: {
            kind: "packed-decimal",
        },
    };


    test("writes positive signed packed decimal", () => {
        const codec =
            packedDecimalCodec(
                signedDecimal,
            );

        const bytes =
            new Uint8Array(3);

        codec.write(
            bytes,
            0,
            3,
            {
                unscaled: 12345n,
                scale: 2,
            },
        );

        expect(
            Array.from(bytes),
        ).toEqual([
            0x12,
            0x34,
            0x5c,
        ]);
    });


    test("writes negative packed decimal", () => {
        const codec =
            packedDecimalCodec(
                signedDecimal,
            );

        const bytes =
            new Uint8Array(3);

        codec.write(
            bytes,
            0,
            3,
            {
                unscaled: -12345n,
                scale: 2,
            },
        );

        expect(
            Array.from(bytes),
        ).toEqual([
            0x12,
            0x34,
            0x5d,
        ]);
    });


    test("writes unsigned packed decimal with F sign", () => {
        const codec =
            packedDecimalCodec(
                unsignedDecimal,
            );

        const bytes =
            new Uint8Array(3);

        codec.write(
            bytes,
            0,
            3,
            {
                unscaled: 12345n,
                scale: 2,
            },
        );

        expect(
            Array.from(bytes),
        ).toEqual([
            0x12,
            0x34,
            0x5f,
        ]);
    });


    test("reads positive packed decimal", () => {
        const codec =
            packedDecimalCodec(
                signedDecimal,
            );

        expect(
            codec.read(
                new Uint8Array([
                    0x12,
                    0x34,
                    0x5c,
                ]),
                0,
                3,
            ),
        ).toEqual({
            unscaled: 12345n,
            scale: 2,
        });
    });


    test("reads negative packed decimal", () => {
        const codec =
            packedDecimalCodec(
                signedDecimal,
            );

        expect(
            codec.read(
                new Uint8Array([
                    0x12,
                    0x34,
                    0x5d,
                ]),
                0,
                3,
            ),
        ).toEqual({
            unscaled: -12345n,
            scale: 2,
        });
    });


    test("validates decimal scale", () => {
        const codec =
            packedDecimalCodec(
                signedDecimal,
            );

        expect(
            codec.validateValue(
                fieldName,
                3,
                {
                    unscaled: 12345n,
                    scale: 3,
                },
            ),
        ).toBe(
            "TEST-FIELD: decimal scale must be 2 but was 3",
        );
    });


    test("validates number of digits", () => {
        const codec =
            packedDecimalCodec(
                signedDecimal,
            );

        expect(
            codec.validateValue(
                fieldName,
                3,
                {
                    unscaled: 123456n,
                    scale: 2,
                },
            ),
        ).toBe(
            "TEST-FIELD: decimal has 6 digits but field allows 5",
        );
    });


    test("validates physical field capacity", () => {
        const type:
            DecimalFieldType = {
            ...signedDecimal,
            digits: 6,
        };

        const codec =
            packedDecimalCodec(
                type,
            );

        expect(
            codec.validateValue(
                fieldName,
                3,
                {
                    unscaled: 1n,
                    scale: 2,
                },
            ),
        ).toBe(
            "TEST-FIELD: decimal type requires 6 digits but 3 bytes can hold only 5",
        );
    });


    test("rejects negative unsigned value", () => {
        const codec =
            packedDecimalCodec(
                unsignedDecimal,
            );

        expect(
            codec.validateValue(
                fieldName,
                3,
                {
                    unscaled: -1n,
                    scale: 2,
                },
            ),
        ).toBe(
            "TEST-FIELD: unsigned decimal cannot contain a negative value",
        );
    });


    test("rejects invalid digit nibble", () => {
        const codec =
            packedDecimalCodec(
                signedDecimal,
            );

        expect(
            codec.validateBytes(
                fieldName,
                new Uint8Array([
                    0x1a,
                    0x34,
                    0x5c,
                ]),
                0,
                3,
            ),
        ).toBe(
            "TEST-FIELD: invalid packed decimal digit at byte 0",
        );
    });


    test("rejects invalid sign nibble", () => {
        const codec =
            packedDecimalCodec(
                signedDecimal,
            );

        expect(
            codec.validateBytes(
                fieldName,
                new Uint8Array([
                    0x12,
                    0x34,
                    0x51,
                ]),
                0,
                3,
            ),
        ).toBe(
            "TEST-FIELD: invalid packed decimal sign nibble 0x1",
        );
    });


    test("rejects negative sign for unsigned decimal", () => {
        const codec =
            packedDecimalCodec(
                unsignedDecimal,
            );

        expect(
            codec.validateBytes(
                fieldName,
                new Uint8Array([
                    0x12,
                    0x34,
                    0x5d,
                ]),
                0,
                3,
            ),
        ).toBe(
            "TEST-FIELD: unsigned packed decimal cannot contain a negative sign",
        );
    });


    test.each([
        0n,
        1n,
        123n,
        12345n,
        -1n,
        -12345n,
    ])(
        "round trips %s",
        unscaled => {
            const codec =
                packedDecimalCodec(
                    signedDecimal,
                );

            const value = {
                unscaled,
                scale: 2,
            };

            expect(
                codec.validateValue(
                    fieldName,
                    3,
                    value,
                ),
            ).toBeUndefined();

            const bytes =
                new Uint8Array(3);

            codec.write(
                bytes,
                0,
                3,
                value,
            );

            expect(
                codec.validateBytes(
                    fieldName,
                    bytes,
                    0,
                    3,
                ),
            ).toBeUndefined();

            expect(
                codec.read(
                    bytes,
                    0,
                    3,
                ),
            ).toEqual(value);
        },
    );

});