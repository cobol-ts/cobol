import {
    Decimal,
    DecimalFieldType,
    FloatingPointFieldType,
    IntegerFieldType,
} from "@cobol-ts/copybookfiles";
import {FileFieldCodec} from "./cobol.codec";


const validateRange = (
    fieldName: string,
    bytes: Uint8Array,
    from: number,
    to: number,
): string | undefined => {
    if (
        from < 0 ||
        to < from ||
        to > bytes.length
    )
        return `${fieldName}: invalid byte range [${from}, ${to}) for array of length ${bytes.length}`;

    return undefined;
};


/*
 * ASCII
 */

export const asciiCodec:
    FileFieldCodec<string> = {

    validateBytes: validateRange,

    read: (
        source,
        from,
        to,
    ) => {
        let result = "";

        for (let i = from; i < to; i++)
            result += String.fromCharCode(
                source[i],
            );

        return result;
    },

    validateValue: (
        fieldName,
        size,
        value,
    ) => {
        if (value.length > size)
            return `${fieldName}: value requires ${value.length} bytes but field has ${size}`;

        for (const character of value)
            if (
                character.codePointAt(0)! >
                0x7f
            )
                return `${fieldName}: character ${JSON.stringify(character)} cannot be encoded as ASCII`;

        return undefined;
    },

    write: (
        target,
        from,
        to,
        value,
    ) => {
        const size =
            to - from;

        for (
            let index = 0;
            index < size;
            index++
        )
            target[from + index] =
                index < value.length
                    ? value.charCodeAt(index)
                    : 0x20;
    },
};


/*
 * Binary integers
 */

export const binaryIntegerCodec = (
    type: IntegerFieldType,
): FileFieldCodec<bigint> => ({

    validateBytes: (
        fieldName,
        source,
        from,
        to,
    ) => {
        const rangeError =
            validateRange(
                fieldName,
                source,
                from,
                to,
            );

        if (rangeError)
            return rangeError;

        if (
            type.encoding.kind !==
            "binary"
        )
            return `${fieldName}: binary integer codec requires binary encoding`;

        if (to === from)
            return `${fieldName}: binary integer field must contain at least one byte`;

        return undefined;
    },

    read: (
        source,
        from,
        to,
    ) => {
        if (
            type.encoding.kind !==
            "binary"
        )
            throw new Error(
                "binaryIntegerCodec requires binary encoding",
            );

        let value = 0n;

        if (
            type.encoding.byteOrder ===
            "big-endian"
        ) {
            for (
                let offset = from;
                offset < to;
                offset++
            )
                value =
                    (value << 8n) |
                    BigInt(source[offset]);
        } else {
            for (
                let offset = to - 1;
                offset >= from;
                offset--
            )
                value =
                    (value << 8n) |
                    BigInt(source[offset]);
        }

        if (type.signed) {
            const bits =
                BigInt(
                    (to - from) * 8,
                );

            const signBit =
                1n << (bits - 1n);

            if (
                (value & signBit) !==
                0n
            )
                value -=
                    1n << bits;
        }

        return value;
    },

    validateValue: (
        fieldName,
        size,
        value,
    ) => {
        if (
            type.encoding.kind !==
            "binary"
        )
            return `${fieldName}: binary integer codec requires binary encoding`;

        if (size <= 0)
            return `${fieldName}: binary integer field must contain at least one byte`;

        const bits =
            BigInt(size * 8);

        if (type.signed) {
            const max =
                (1n << (bits - 1n)) -
                1n;

            const min =
                -(1n << (bits - 1n));

            if (
                value < min ||
                value > max
            )
                return `${fieldName}: value ${value} does not fit in signed ${size}-byte integer`;

            return undefined;
        }

        if (value < 0)
            return `${fieldName}: unsigned integer cannot contain a negative value`;

        const max =
            (1n << bits) -
            1n;

        if (value > max)
            return `${fieldName}: value ${value} does not fit in unsigned ${size}-byte integer`;

        return undefined;
    },

    write: (
        target,
        from,
        to,
        value,
    ) => {
        if (
            type.encoding.kind !==
            "binary"
        )
            throw new Error(
                "binaryIntegerCodec requires binary encoding",
            );

        const byteCount =
            to - from;

        const bits =
            BigInt(
                byteCount * 8,
            );

        let encoded =
            value;

        if (encoded < 0)
            encoded +=
                1n << bits;

        if (
            type.encoding.byteOrder ===
            "big-endian"
        ) {
            for (
                let offset = to - 1;
                offset >= from;
                offset--
            ) {
                target[offset] =
                    Number(
                        encoded & 0xffn,
                    );

                encoded >>= 8n;
            }
        } else {
            for (
                let offset = from;
                offset < to;
                offset++
            ) {
                target[offset] =
                    Number(
                        encoded & 0xffn,
                    );

                encoded >>= 8n;
            }
        }
    },
});


/*
 * IEEE-754 floating point
 */

export const ieee754Codec = (
    type: FloatingPointFieldType,
): FileFieldCodec<number> => ({

    validateBytes: (
        fieldName,
        source,
        from,
        to,
    ) => {
        const rangeError =
            validateRange(
                fieldName,
                source,
                from,
                to,
            );

        if (rangeError)
            return rangeError;

        if (
            type.encoding.kind !==
            "ieee754"
        )
            return `${fieldName}: IEEE-754 codec requires ieee754 encoding`;

        const expectedSize =
            type.encoding.precision ===
            "single"
                ? 4
                : 8;

        if (
            to - from !==
            expectedSize
        )
            return `${fieldName}: IEEE-754 ${type.encoding.precision} requires ${expectedSize} bytes but field has ${to - from}`;

        return undefined;
    },

    read: (
        source,
        from,
        _to,
    ) => {
        if (
            type.encoding.kind !==
            "ieee754"
        )
            throw new Error(
                "ieee754Codec requires ieee754 encoding",
            );

        const view =
            new DataView(
                source.buffer,
                source.byteOffset + from,
            );

        const littleEndian =
            type.encoding.byteOrder ===
            "little-endian";

        return type.encoding.precision ===
        "single"
            ? view.getFloat32(
                0,
                littleEndian,
            )
            : view.getFloat64(
                0,
                littleEndian,
            );
    },

    validateValue: (
        fieldName,
        size,
        value,
    ) => {
        if (
            type.encoding.kind !==
            "ieee754"
        )
            return `${fieldName}: IEEE-754 codec requires ieee754 encoding`;

        const expectedSize =
            type.encoding.precision ===
            "single"
                ? 4
                : 8;

        if (size !== expectedSize)
            return `${fieldName}: IEEE-754 ${type.encoding.precision} requires ${expectedSize} bytes but field has ${size}`;

        if (typeof value !== "number")
            return `${fieldName}: floating point value must be a number`;

        return undefined;
    },

    write: (
        target,
        from,
        _to,
        value,
    ) => {
        if (
            type.encoding.kind !==
            "ieee754"
        )
            throw new Error(
                "ieee754Codec requires ieee754 encoding",
            );

        const view =
            new DataView(
                target.buffer,
                target.byteOffset + from,
            );

        const littleEndian =
            type.encoding.byteOrder ===
            "little-endian";

        if (
            type.encoding.precision ===
            "single"
        )
            view.setFloat32(
                0,
                value,
                littleEndian,
            );
        else
            view.setFloat64(
                0,
                value,
                littleEndian,
            );
    },
});


/*
 * Packed decimal
 */

export const packedDecimalCodec = (
    type: DecimalFieldType,
): FileFieldCodec<Decimal> => ({

    validateBytes: (
        fieldName,
        source,
        from,
        to,
    ) => {
        const rangeError =
            validateRange(
                fieldName,
                source,
                from,
                to,
            );

        if (rangeError)
            return rangeError;

        if (
            type.encoding.kind !==
            "packed-decimal"
        )
            return `${fieldName}: packed decimal codec requires packed-decimal encoding`;

        if (to === from)
            return `${fieldName}: packed decimal field must contain at least one byte`;

        for (
            let offset = from;
            offset < to - 1;
            offset++
        ) {
            const high =
                source[offset] >> 4;

            const low =
                source[offset] & 0x0f;

            if (
                high > 9 ||
                low > 9
            )
                return `${fieldName}: invalid packed decimal digit at byte ${offset - from}`;
        }

        const finalByte =
            source[to - 1];

        const high =
            finalByte >> 4;

        const sign =
            finalByte & 0x0f;

        if (high > 9)
            return `${fieldName}: invalid final packed decimal digit`;

        if (
            sign !== 0x0c &&
            sign !== 0x0d &&
            sign !== 0x0f
        )
            return `${fieldName}: invalid packed decimal sign nibble 0x${sign.toString(16)}`;

        if (
            !type.signed &&
            sign === 0x0d
        )
            return `${fieldName}: unsigned packed decimal cannot contain a negative sign`;

        return undefined;
    },

    read: (
        source,
        from,
        to,
    ) => {
        let unscaled = 0n;

        for (
            let offset = from;
            offset < to;
            offset++
        ) {
            const byte =
                source[offset];

            const high =
                byte >> 4;

            unscaled =
                unscaled * 10n +
                BigInt(high);

            if (
                offset <
                to - 1
            ) {
                const low =
                    byte & 0x0f;

                unscaled =
                    unscaled * 10n +
                    BigInt(low);
            }
        }

        const sign =
            source[to - 1] &
            0x0f;

        if (sign === 0x0d)
            unscaled =
                -unscaled;

        return {
            unscaled,
            scale: type.scale,
        };
    },

    validateValue: (
        fieldName,
        size,
        value,
    ) => {
        if (
            type.encoding.kind !==
            "packed-decimal"
        )
            return `${fieldName}: packed decimal codec requires packed-decimal encoding`;

        if (size <= 0)
            return `${fieldName}: packed decimal field must contain at least one byte`;

        if (
            value.scale !==
            type.scale
        )
            return `${fieldName}: decimal scale must be ${type.scale} but was ${value.scale}`;

        if (
            !type.signed &&
            value.unscaled < 0
        )
            return `${fieldName}: unsigned decimal cannot contain a negative value`;

        const physicalDigits =
            size * 2 - 1;

        if (
            type.digits >
            physicalDigits
        )
            return `${fieldName}: decimal type requires ${type.digits} digits but ${size} bytes can hold only ${physicalDigits}`;

        const magnitude =
            value.unscaled < 0
                ? -value.unscaled
                : value.unscaled;

        const digits =
            magnitude.toString().length;

        if (
            digits >
            type.digits
        )
            return `${fieldName}: decimal has ${digits} digits but field allows ${type.digits}`;

        return undefined;
    },

    write: (
        target,
        from,
        to,
        value,
    ) => {
        const negative =
            value.unscaled < 0;

        const physicalDigits =
            (to - from) * 2 - 1;

        const digits =
            (
                negative
                    ? -value.unscaled
                    : value.unscaled
            )
                .toString()
                .padStart(
                    physicalDigits,
                    "0",
                );

        let digitIndex = 0;

        for (
            let offset = from;
            offset < to - 1;
            offset++
        ) {
            const high =
                Number(
                    digits[digitIndex++],
                );

            const low =
                Number(
                    digits[digitIndex++],
                );

            target[offset] =
                (high << 4) |
                low;
        }

        const finalDigit =
            Number(
                digits[digitIndex],
            );

        const sign =
            negative
                ? 0x0d
                : type.signed
                    ? 0x0c
                    : 0x0f;

        target[to - 1] =
            (finalDigit << 4) |
            sign;
    },
});