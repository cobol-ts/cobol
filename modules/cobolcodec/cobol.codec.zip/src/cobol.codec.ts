import {
    Decimal,
    DecimalFieldType,
    FileFieldType,
    FileFieldValue,
    FloatingPointFieldType,
    IntegerFieldType,
    TextFieldType,
} from "@cobol-ts/copybookfiles";
import {asciiCodec} from "./primitive.codec";


export type ValueValidator<T> =
    (
        fieldName: string,
        size: number,
        value: T,
    ) => string | undefined;


export type ByteValidator =
    (
        fieldName: string,
        source: Uint8Array,
        from: number,
        to: number,
    ) => string | undefined;


export type ByteReader<T> =
    (
        source: Uint8Array,
        from: number,
        to: number,
    ) => T;


export type ByteWriter<T> =
    (
        target: Uint8Array,
        from: number,
        to: number,
        value: T,
    ) => void;


export type FileFieldCodec<
    T extends FileFieldValue = FileFieldValue
> = {
    validateBytes: ByteValidator;

    read: ByteReader<T>;

    validateValue: ValueValidator<T>;

    write: ByteWriter<T>;
};


export type FileCodecConfig = {
    text:
        (
            type: TextFieldType,
        ) => FileFieldCodec<string>;

    integer:
        (
            type: IntegerFieldType,
        ) => FileFieldCodec<bigint>;

    decimal:
        (
            type: DecimalFieldType,
        ) => FileFieldCodec<Decimal>;

    "floating-point":
        (
            type: FloatingPointFieldType,
        ) => FileFieldCodec<number>;
};

export const defaultFileCodecConfig: FileCodecConfig = {
    text:() =>asciiCodec,
    integer:() => { throw new Error("Integer codec not implemented"); },
    decimal:() => { throw new Error("Decimal codec not implemented"); },
    "floating-point":() => { throw new Error("Floating-point codec not implemented"); },
}